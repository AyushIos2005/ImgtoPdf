[app]

# App name shown on home screen
title = Img to PDF

# Package name (must be unique)
package.name = imgtopdf
package.domain = org.ayush

# Entry point
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,ttf

# App version
version = 1.0

# Python requirements
requirements = python3,kivy==2.3.0,kivymd,pillow,reportlab

# App icon (our custom A icon)
icon.filename = %(source.dir)s/icon.png

# Presplash / loading screen
presplash.filename = %(source.dir)s/presplash.png
presplash.color = #1A1A2E

# Android settings
android.permissions = READ_EXTERNAL_STORAGE,WRITE_EXTERNAL_STORAGE,INTERNET
android.api = 33
android.minapi = 21
android.ndk = 25b
android.sdk = 33
android.archs = arm64-v8a, armeabi-v7a
android.allow_backup = True
android.orientation = portrait

# App store metadata
android.apptheme = "@android:style/Theme.NoTitleBar"

# Gradle extras
android.gradle_dependencies = 

# Build settings
log_level = 2
warn_on_root = 1
p4a.branch = master

[buildozer]
log_level = 2
warn_on_root = 1
