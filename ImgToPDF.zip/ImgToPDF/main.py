"""
Image → PDF  Android App
Built with Kivy + KivyMD + reportlab
Max 15 pages | App icon: "A"
"""

from kivy.config import Config
Config.set('graphics', 'resizable', '0')

from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.image import Image as KivyImage
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivy.uix.progressbar import ProgressBar
from kivy.uix.spinner import Spinner
from kivy.uix.switch import Switch
from kivy.uix.filechooser import FileChooserIconView
from kivy.uix.floatlayout import FloatLayout
from kivy.graphics import Color, RoundedRectangle, Rectangle
from kivy.metrics import dp, sp
from kivy.clock import Clock
from kivy.core.window import Window

import threading
import os
import io
from datetime import datetime

try:
    from reportlab.lib.pagesizes import A4, LETTER, A5, landscape
    from reportlab.pdfgen import canvas as rl_canvas
    REPORTLAB_OK = True
except ImportError:
    REPORTLAB_OK = False

try:
    from PIL import Image as PILImage
    PIL_OK = True
except ImportError:
    PIL_OK = False

# ── Android storage helper ────────────────────────────────────────────────────
try:
    from android.permissions import request_permissions, Permission
    from android.storage import primary_external_storage_path
    IS_ANDROID = True
except ImportError:
    IS_ANDROID = False

MAX_PAGES = 15

PAGE_SIZES = {
    "A4":     A4     if REPORTLAB_OK else (595, 842),
    "Letter": LETTER if REPORTLAB_OK else (612, 792),
    "A5":     A5     if REPORTLAB_OK else (420, 595),
}

# ── Colours ───────────────────────────────────────────────────────────────────
C_HEADER  = (0.102, 0.102, 0.180, 1)   # #1A1A2E
C_ACCENT  = (0.424, 0.388, 1.0,   1)   # #6C63FF
C_WHITE   = (1,     1,     1,     1)
C_BG      = (0.96,  0.96,  0.96,  1)
C_GRAY    = (0.69,  0.69,  0.69,  1)
C_TEXT    = (0.13,  0.13,  0.13,  1)
C_TEXT2   = (0.46,  0.46,  0.46,  1)
C_DANGER  = (0.898, 0.224, 0.208, 1)
C_SUCCESS = (0.263, 0.627, 0.278, 1)


def hex_color(h):
    h = h.lstrip('#')
    return tuple(int(h[i:i+2], 16)/255 for i in (0, 2, 4)) + (1,)


# ── Rounded card widget ───────────────────────────────────────────────────────
class Card(BoxLayout):
    def __init__(self, radius=dp(14), bg_color=C_WHITE, **kwargs):
        super().__init__(**kwargs)
        self._radius = radius
        self._bg = bg_color
        with self.canvas.before:
            Color(*bg_color)
            self._rect = RoundedRectangle(pos=self.pos, size=self.size,
                                          radius=[radius])
        self.bind(pos=self._update, size=self._update)

    def _update(self, *_):
        self._rect.pos  = self.pos
        self._rect.size = self.size


# ── Accent button ─────────────────────────────────────────────────────────────
class AccentButton(Button):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.background_normal   = ''
        self.background_color    = C_ACCENT
        self.color               = C_WHITE
        self.font_size           = sp(14)
        self.bold                = True
        self.size_hint_y         = None
        self.height              = dp(48)


class DarkButton(Button):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.background_normal   = ''
        self.background_color    = C_HEADER
        self.color               = C_WHITE
        self.font_size           = sp(15)
        self.bold                = True
        self.size_hint_y         = None
        self.height              = dp(54)


class DangerButton(Button):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.background_normal  = ''
        self.background_color   = C_DANGER
        self.color              = C_WHITE
        self.font_size          = sp(11)
        self.bold               = True
        self.size_hint          = (None, None)
        self.size               = (dp(28), dp(28))


# ── Main screen ───────────────────────────────────────────────────────────────
class MainScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.selected_images = []   # list of absolute paths
        self._build()

    def _build(self):
        root = BoxLayout(orientation='vertical', spacing=0)

        # ── Header ──
        header = BoxLayout(orientation='horizontal',
                           size_hint_y=None, height=dp(60),
                           padding=[dp(16), dp(8)])
        with header.canvas.before:
            Color(*C_HEADER)
            self._hdr_rect = Rectangle(pos=header.pos, size=header.size)
        header.bind(pos=lambda *a: setattr(self._hdr_rect, 'pos', header.pos),
                    size=lambda *a: setattr(self._hdr_rect, 'size', header.size))

        icon = Label(text='[b]A[/b]', markup=True,
                     font_size=sp(22), color=C_ACCENT,
                     size_hint=(None, 1), width=dp(40))
        t_col = BoxLayout(orientation='vertical')
        t_col.add_widget(Label(text='[b]Img → PDF[/b]', markup=True,
                               font_size=sp(16), color=C_WHITE,
                               halign='left', text_size=(None, None)))
        t_col.add_widget(Label(text='Maximum 15 pages',
                               font_size=sp(10), color=(0.7,0.7,0.7,1),
                               halign='left', text_size=(None, None)))
        header.add_widget(icon)
        header.add_widget(t_col)
        root.add_widget(header)

        # ── Scrollable body ──
        scroll = ScrollView(size_hint=(1, 1))
        body   = BoxLayout(orientation='vertical', spacing=dp(10),
                           padding=[dp(12), dp(12)],
                           size_hint_y=None)
        body.bind(minimum_height=body.setter('height'))

        # Add-images card
        add_card = Card(orientation='vertical', spacing=dp(8),
                        padding=[dp(16), dp(16)],
                        size_hint_y=None, height=dp(160))
        add_card.add_widget(Label(text='🖼', font_size=sp(36),
                                  size_hint_y=None, height=dp(44)))
        add_card.add_widget(Label(text='[b]Tap to add images[/b]', markup=True,
                                  font_size=sp(13), color=C_TEXT,
                                  size_hint_y=None, height=dp(20)))
        add_card.add_widget(Label(text='JPG · PNG · WEBP — up to 15 images',
                                  font_size=sp(10), color=C_TEXT2,
                                  size_hint_y=None, height=dp(18)))
        add_btn = AccentButton(text='+ Choose Images')
        add_btn.bind(on_release=self.open_file_chooser)
        add_card.add_widget(add_btn)
        body.add_widget(add_card)

        # Counter row
        counter_row = BoxLayout(orientation='horizontal',
                                size_hint_y=None, height=dp(30))
        self.count_lbl = Label(text='0 images selected',
                               font_size=sp(11), color=C_TEXT2,
                               halign='left', text_size=(None, None))
        self.badge_lbl = Label(text='0 / 15',
                               font_size=sp(11), color=C_ACCENT,
                               bold=True, halign='right',
                               text_size=(None, None))
        counter_row.add_widget(self.count_lbl)
        counter_row.add_widget(self.badge_lbl)
        body.add_widget(counter_row)

        # Thumbnail grid
        self.thumb_grid = GridLayout(cols=3, spacing=dp(6),
                                     size_hint_y=None, padding=[0, 0])
        self.thumb_grid.bind(minimum_height=self.thumb_grid.setter('height'))
        self.empty_lbl = Label(text='No images selected yet',
                               font_size=sp(11), color=C_GRAY,
                               size_hint_y=None, height=dp(60))
        self.thumb_grid.add_widget(self.empty_lbl)
        body.add_widget(self.thumb_grid)

        # Settings card
        settings_card = Card(orientation='vertical', spacing=dp(8),
                             padding=[dp(14), dp(12)],
                             size_hint_y=None, height=dp(170))

        settings_card.add_widget(self._setting_row(
            'Page size', ['A4', 'Letter', 'A5'], 'page_spinner'))
        settings_card.add_widget(self._setting_row(
            'Orientation', ['Portrait', 'Landscape'], 'orient_spinner'))
        settings_card.add_widget(self._fit_row())
        body.add_widget(settings_card)

        # Progress bar (hidden initially)
        self.progress_bar = ProgressBar(max=100, value=0,
                                        size_hint_y=None, height=dp(8),
                                        opacity=0)
        body.add_widget(self.progress_bar)

        # Convert button
        self.convert_btn = DarkButton(text='Convert to PDF  ↓')
        self.convert_btn.bind(on_release=self.convert_to_pdf)
        self.convert_btn.disabled = True
        body.add_widget(self.convert_btn)

        # Status label
        self.status_lbl = Label(text='', font_size=sp(10), color=C_TEXT2,
                                size_hint_y=None, height=dp(24))
        body.add_widget(self.status_lbl)

        # Padding at bottom
        body.add_widget(Label(size_hint_y=None, height=dp(20)))

        scroll.add_widget(body)
        root.add_widget(scroll)
        self.add_widget(root)

    def _setting_row(self, label_text, options, attr_name):
        row = BoxLayout(orientation='horizontal',
                        size_hint_y=None, height=dp(40))
        row.add_widget(Label(text=label_text, font_size=sp(12),
                             color=C_TEXT, halign='left',
                             text_size=(None, None)))
        spinner = Spinner(text=options[0], values=options,
                          size_hint=(None, None),
                          size=(dp(120), dp(36)),
                          font_size=sp(11))
        setattr(self, attr_name, spinner)
        row.add_widget(spinner)
        return row

    def _fit_row(self):
        row = BoxLayout(orientation='horizontal',
                        size_hint_y=None, height=dp(40))
        row.add_widget(Label(text='Fit image to page', font_size=sp(12),
                             color=C_TEXT, halign='left',
                             text_size=(None, None)))
        self.fit_switch = Switch(active=True, size_hint=(None, 1),
                                 width=dp(80))
        row.add_widget(self.fit_switch)
        return row

    # ── File chooser ─────────────────────────────────────────────────────────

    def open_file_chooser(self, *_):
        if IS_ANDROID:
            request_permissions([Permission.READ_EXTERNAL_STORAGE,
                                  Permission.WRITE_EXTERNAL_STORAGE])

        remaining = MAX_PAGES - len(self.selected_images)
        if remaining <= 0:
            self._toast('Maximum 15 pages already selected!')
            return

        content = FloatLayout()
        start_path = (primary_external_storage_path()
                      if IS_ANDROID else os.path.expanduser('~'))

        fc = FileChooserIconView(
            path=start_path,
            filters=['*.jpg', '*.jpeg', '*.png', '*.webp',
                     '*.bmp', '*.JPG', '*.PNG', '*.JPEG'],
            multiselect=True,
            size_hint=(1, 0.85),
            pos_hint={'top': 1})
        content.add_widget(fc)

        btn_row = BoxLayout(orientation='horizontal',
                            size_hint=(1, None), height=dp(48),
                            pos_hint={'y': 0}, spacing=dp(8),
                            padding=[dp(8), dp(4)])

        cancel_btn = Button(text='Cancel', background_color=C_HEADER,
                            background_normal='', color=C_WHITE,
                            font_size=sp(13))
        select_btn = Button(text='Add Selected', background_color=C_ACCENT,
                            background_normal='', color=C_WHITE,
                            font_size=sp(13), bold=True)
        btn_row.add_widget(cancel_btn)
        btn_row.add_widget(select_btn)
        content.add_widget(btn_row)

        popup = Popup(title='Select Images',
                      content=content,
                      size_hint=(0.95, 0.9))

        cancel_btn.bind(on_release=popup.dismiss)
        select_btn.bind(on_release=lambda *a: self._add_files(fc.selection, popup))
        popup.open()

    def _add_files(self, paths, popup):
        popup.dismiss()
        remaining = MAX_PAGES - len(self.selected_images)
        added, skipped = 0, []

        for p in paths[:remaining]:
            if not os.path.isfile(p):
                continue
            if p not in self.selected_images:
                self.selected_images.append(p)
                added += 1

        if len(paths) > remaining:
            self._toast(f'Only {remaining} more image(s) allowed (limit 15)')

        self._refresh_grid()
        self._update_state()

    # ── Thumbnail grid ────────────────────────────────────────────────────────

    def _refresh_grid(self):
        self.thumb_grid.clear_widgets()
        if not self.selected_images:
            self.thumb_grid.add_widget(self.empty_lbl)
            return

        self.thumb_grid.cols = 3
        for idx, path in enumerate(self.selected_images):
            cell = FloatLayout(size_hint_y=None, height=dp(100))
            try:
                img_w = KivyImage(source=path,
                                  allow_stretch=True,
                                  keep_ratio=True,
                                  size_hint=(1, 1))
                cell.add_widget(img_w)
            except Exception:
                cell.add_widget(Label(text='?', font_size=sp(24),
                                      color=C_GRAY))

            num_lbl = Label(
                text=f'[b]#{idx+1}[/b]', markup=True,
                font_size=sp(10), color=C_WHITE,
                size_hint=(None, None), size=(dp(28), dp(18)),
                pos_hint={'x': 0, 'top': 1})
            with num_lbl.canvas.before:
                Color(*C_ACCENT)
                RoundedRectangle(pos=num_lbl.pos, size=num_lbl.size,
                                 radius=[dp(4)])
            cell.add_widget(num_lbl)

            rm = DangerButton(text='✕')
            rm.pos_hint = {'right': 1, 'top': 1}
            rm.bind(on_release=lambda *a, i=idx: self._remove(i))
            cell.add_widget(rm)

            self.thumb_grid.add_widget(cell)

    def _remove(self, idx):
        if 0 <= idx < len(self.selected_images):
            self.selected_images.pop(idx)
            self._refresh_grid()
            self._update_state()

    def _update_state(self):
        n = len(self.selected_images)
        self.count_lbl.text = f'{n} image{"s" if n!=1 else ""} selected'
        self.badge_lbl.text = f'{n} / {MAX_PAGES}'
        self.convert_btn.disabled = (n == 0)

    # ── PDF conversion ────────────────────────────────────────────────────────

    def convert_to_pdf(self, *_):
        if not self.selected_images:
            return
        if not REPORTLAB_OK:
            self._toast('reportlab not installed!')
            return

        # Build output path
        if IS_ANDROID:
            out_dir = os.path.join(primary_external_storage_path(),
                                   'Documents')
        else:
            out_dir = os.path.expanduser('~/Documents')

        os.makedirs(out_dir, exist_ok=True)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        out_path = os.path.join(out_dir, f'ImgToPDF_{timestamp}.pdf')

        self.convert_btn.disabled = True
        self.convert_btn.text = 'Building PDF…'
        self.progress_bar.opacity = 1
        self.progress_bar.value = 0
        self.status_lbl.color = C_TEXT2
        self.status_lbl.text = 'Starting…'

        thread = threading.Thread(
            target=self._convert_thread,
            args=(out_path,), daemon=True)
        thread.start()

    def _convert_thread(self, out_path):
        try:
            size_key = self.page_spinner.text
            orient   = self.orient_spinner.text
            fit      = self.fit_switch.active
            psize    = PAGE_SIZES.get(size_key, A4)

            if orient == 'Landscape':
                psize = landscape(psize)
            pw, ph = psize

            c = rl_canvas.Canvas(out_path, pagesize=psize)
            total = len(self.selected_images)

            for i, img_path in enumerate(self.selected_images):
                if PIL_OK:
                    pil = PILImage.open(img_path).convert('RGB')
                    iw, ih = pil.size
                    buf = io.BytesIO()
                    pil.save(buf, format='JPEG', quality=88)
                    buf.seek(0)
                    from reportlab.lib.utils import ImageReader
                    img_reader = ImageReader(buf)
                else:
                    from reportlab.lib.utils import ImageReader
                    img_reader = ImageReader(img_path)
                    iw = ih = 1

                if fit:
                    if PIL_OK:
                        scale = min(pw / iw, ph / ih)
                        dw, dh = iw * scale, ih * scale
                    else:
                        dw, dh = pw, ph
                    x = (pw - dw) / 2
                    y = (ph - dh) / 2
                else:
                    dw, dh, x, y = pw, ph, 0, 0

                c.drawImage(img_reader, x, y, width=dw, height=dh,
                            preserveAspectRatio=False)

                if i < total - 1:
                    c.showPage()

                pct = int((i + 1) / total * 100)
                Clock.schedule_once(
                    lambda dt, p=pct, n=i+1, t=total:
                        self._update_progress(p, n, t), 0)

            c.save()
            Clock.schedule_once(
                lambda dt: self._on_success(out_path, total), 0)

        except Exception as exc:
            Clock.schedule_once(
                lambda dt, e=str(exc): self._on_error(e), 0)

    def _update_progress(self, pct, n, total):
        self.progress_bar.value = pct
        self.status_lbl.text = f'Processing {n} / {total}…'

    def _on_success(self, path, pages):
        self.progress_bar.opacity = 0
        self.convert_btn.disabled = False
        self.convert_btn.text = 'Convert to PDF  ↓'
        self.status_lbl.color = C_SUCCESS
        self.status_lbl.text = f'✔  Saved — {pages} page{"s" if pages!=1 else ""}'
        self._toast(f'PDF saved!\n{os.path.basename(path)}')

    def _on_error(self, msg):
        self.progress_bar.opacity = 0
        self.convert_btn.disabled = False
        self.convert_btn.text = 'Convert to PDF  ↓'
        self.status_lbl.color = C_DANGER
        self.status_lbl.text = f'Error: {msg}'

    def _toast(self, msg):
        box = BoxLayout(orientation='vertical', padding=dp(10))
        box.add_widget(Label(text=msg, font_size=sp(13),
                             halign='center', text_size=(dp(240), None)))
        popup = Popup(title='', content=box,
                      size_hint=(0.75, None), height=dp(120),
                      separator_height=0)
        popup.open()
        Clock.schedule_once(popup.dismiss, 2.5)


# ── App class ─────────────────────────────────────────────────────────────────
class ImgToPDFApp(App):
    def build(self):
        Window.clearcolor = C_BG
        sm = ScreenManager()
        sm.add_widget(MainScreen(name='main'))
        return sm

    def on_start(self):
        if IS_ANDROID:
            request_permissions([
                Permission.READ_EXTERNAL_STORAGE,
                Permission.WRITE_EXTERNAL_STORAGE,
            ])


if __name__ == '__main__':
    ImgToPDFApp().run()
