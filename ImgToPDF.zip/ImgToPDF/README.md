# Img → PDF  Android App
**Max 15 pages | App icon: "A"**

---

## Project Structure
```
ImgToPDF/
├── main.py          ← Kivy app (all UI + PDF logic)
├── buildozer.spec   ← Android build config
├── icon.png         ← App icon (navy bg + purple "A")
├── presplash.png    ← Loading screen
└── README.md
```

---

## Step 1 — Install build tools (Ubuntu/WSL recommended)

> **Windows users**: Use WSL2 (Windows Subsystem for Linux) or a Linux VM.
> Buildozer does NOT run natively on Windows.

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install system dependencies
sudo apt install -y \
    git zip unzip openjdk-17-jdk \
    python3 python3-pip \
    libffi-dev libssl-dev \
    autoconf libtool pkg-config \
    zlib1g-dev libncurses5-dev \
    libncursesw5-dev libtinfo5 \
    cmake libstdc++6 build-essential

# Install Python packages
pip3 install --upgrade buildozer cython==0.29.33 kivy kivymd pillow reportlab
```

---

## Step 2 — Set up Android SDK/NDK (auto via buildozer)

Buildozer downloads the Android SDK and NDK automatically on first build.
Make sure you have ~8 GB free disk space.

---

## Step 3 — Build the APK

```bash
# Navigate to project folder
cd ImgToPDF/

# First build (downloads SDK/NDK — takes 10–30 min)
buildozer android debug

# The APK will be at:
#   bin/imgtopdf-1.0-arm64-v8a_armeabi-v7a-debug.apk
```

---

## Step 4 — Install on your Android phone

### Option A — USB (fastest)
```bash
# Enable USB Debugging on phone:
# Settings → About Phone → tap Build Number 7×
# Settings → Developer Options → USB Debugging ON

# Connect phone via USB, then:
buildozer android deploy run

# Or use adb directly:
adb install bin/*.apk
```

### Option B — Copy APK file
1. Copy the `.apk` from `bin/` to your phone (via USB / Google Drive / email)
2. On phone: Settings → Security → **Allow install from unknown sources**
3. Tap the APK file to install

---

## App Features
| Feature | Detail |
|---------|--------|
| Max images | 15 (hard limit enforced) |
| Formats | JPG, PNG, WEBP, BMP |
| Page sizes | A4, Letter, A5 |
| Orientation | Portrait / Landscape |
| Fit to page | Toggle on/off |
| Output | Saved to `Documents/ImgToPDF_YYYYMMDD_HHMMSS.pdf` |
| Icon | Navy background + purple "A" |

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `buildozer` not found | `pip3 install buildozer` |
| Java error | Install `openjdk-17-jdk` |
| NDK download fails | Check internet, retry `buildozer android debug` |
| App crashes on phone | Run `buildozer android logcat` to see logs |
| PIL import error | Ensure `pillow` is in `requirements` in buildozer.spec |

---

## Release APK (for Play Store / sharing without "unknown sources")

```bash
# Generate a signing key (one time)
keytool -genkey -v -keystore my-release-key.jks \
    -alias imgtopdf -keyalg RSA -keysize 2048 -validity 10000

# Build release APK
buildozer android release

# Sign it
jarsigner -verbose -sigalg SHA256withRSA -digestalg SHA-256 \
    -keystore my-release-key.jks \
    bin/imgtopdf-1.0-*-release-unsigned.apk imgtopdf

# Align
zipalign -v 4 bin/imgtopdf-1.0-*-release-unsigned.apk \
    bin/imgtopdf-release.apk
```
